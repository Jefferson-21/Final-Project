/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author JINESH
 */
public class Hospital {
    String GTAHospital;
    String GlobalHospital;

    public String getGTAHospital() {
        return GTAHospital;
    }

    public void setGTAHospital(String GTAHospital) {
        this.GTAHospital = GTAHospital;
    }

    public String getGlobalHospital() {
        return GlobalHospital;
    }

    public void setGlobalHospital(String GlobalHospital) {
        this.GlobalHospital = GlobalHospital;
    }
     
}
