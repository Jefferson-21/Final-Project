/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author jeyarajjeyakumar
 */
public class Ambulance {
    String Patientname;
    String PatientnameID;
    String AmbulanceID;
    String DriverName;
    String DropOff;
    String PickUp;
    String ContactNumber;

    public String getPatientname() {
        return Patientname;
    }

    public void setPatientname(String Patientname) {
        this.Patientname = Patientname;
    }

    public String getPatientnameID() {
        return PatientnameID;
    }

    public void setPatientnameID(String PatientnameID) {
        this.PatientnameID = PatientnameID;
    }

    public String getAmbulanceID() {
        return AmbulanceID;
    }

    public void setAmbulanceID(String AmbulanceID) {
        this.AmbulanceID = AmbulanceID;
    }

    public String getDriverName() {
        return DriverName;
    }

    public void setDriverName(String DriverName) {
        this.DriverName = DriverName;
    }

    public String getDropOff() {
        return DropOff;
    }

    public void setDropOff(String DropOff) {
        this.DropOff = DropOff;
    }

    public String getPickUp() {
        return PickUp;
    }

    public void setPickUp(String PickUp) {
        this.PickUp = PickUp;
    }

    public String getContactNumber() {
        return ContactNumber;
    }

    public void setContactNumber(String ContactNumber) {
        this.ContactNumber = ContactNumber;
    }
    
}
