/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author JINESH
 */
public class VitalSigns {
    int BP;
    int BloodSugar;
    int HeartRate;

    public int getBP() {
        return BP;
    }

    public void setBP(int BP) {
        this.BP = BP;
    }

    public int getBloodSugar() {
        return BloodSugar;
    }

    public void setBloodSugar(int BloodSugar) {
        this.BloodSugar = BloodSugar;
    }

    public int getHeartRate() {
        return HeartRate;
    }

    public void setHeartRate(int HeartRate) {
        this.HeartRate = HeartRate;
    }
    
  
    
}
