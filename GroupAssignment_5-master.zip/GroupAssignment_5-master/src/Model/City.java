/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author JINESH
 */
public class City {
    String Toronto;
    String Vancouver;

    public String getToronto() {
        return Toronto;
    }

    public void setToronto(String Toronto) {
        this.Toronto = Toronto;
    }

    public String getVancouver() {
        return Vancouver;
    }

    public void setVancouver(String Vancouver) {
        this.Vancouver = Vancouver;
    }
    
}
